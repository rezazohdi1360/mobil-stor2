<?php
/**
 * صفحه اصلی فروشگاه - طراحی کلاسیک
 */
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/coupons.php';

// صفحه خوش‌آمدگویی: یک‌بار در هر نشست، هنگام ورود به صفحه اصلی
if (session_status() === PHP_SESSION_NONE) session_start();
if ($_SERVER['REQUEST_METHOD'] === 'GET' && empty($_SESSION['welcomed']) && !isset($_GET['skip']) && welcome_enabled($pdo)) {
    header('Location: welcome.php');
    exit;
}

// کدهای تخفیف فعال برای نمایش در Hero
$heroCoupons = [];
try {
    coupons_ensure($pdo);
    $cnt = $pdo->prepare("SELECT COUNT(*) FROM coupon_products WHERE coupon_id = ?");
    foreach ($pdo->query("SELECT * FROM coupons WHERE status = 1 ORDER BY ends_at ASC, id DESC LIMIT 12")->fetchAll() as $cp) {
        if (coupon_state($cp) !== 'active') continue;
        $cnt->execute([$cp['id']]); $cp['n_products'] = (int)$cnt->fetchColumn();
        $heroCoupons[] = $cp;
        if (count($heroCoupons) >= 4) break;
    }
} catch (Throwable $e) { $heroCoupons = []; }

// ============================================================
// توابع کمکی نمایش (فقط در صورت نبودن تعریف می‌شوند)
// ============================================================
if (!function_exists('ms_fa_digits')) {
    function ms_fa_digits($value) {
        return strtr((string)$value, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']);
    }
}
if (!function_exists('ms_money')) {
    function ms_money($n) {
        return ms_fa_digits(number_format((float)$n));
    }
}
if (!function_exists('ms_product_card')) {
    function ms_product_card(array $p, bool $forceDiscount = false): void {
        $isAvailable = ($p['stock_status'] === 'in_stock' && $p['stock'] > 0 && $p['price'] > 0);
        $hasSale = ($p['sale_price'] && $p['sale_price'] > 0 && $p['sale_price'] < $p['price']);
        ?>
        <article class="product-card <?= !$isAvailable ? 'out-of-stock' : '' ?>">
            <?php if (!$isAvailable): ?>
                <span class="ribbon ribbon-off">ناموجود</span>
            <?php elseif ($hasSale): ?>
                <span class="ribbon ribbon-sale"><?= ms_fa_digits((int)$p['discount_percent']) ?>٪ تخفیف</span>
            <?php endif; ?>
            <a href="product.php?id=<?= (int)$p['id'] ?>" class="product-image">
                <img src="<?= htmlspecialchars($p['main_image'] ?: 'icon/placeholder/no-image.png') ?>"
                     alt="<?= htmlspecialchars($p['name']) ?>" loading="lazy"
                     onerror="this.onerror=null;this.src='icon/placeholder/no-image.png'">
            </a>
            <div class="product-info">
                <h3 class="product-title">
                    <a href="product.php?id=<?= (int)$p['id'] ?>"><?= htmlspecialchars(mb_substr($p['name'], 0, 70)) ?></a>
                </h3>
                <div class="product-price">
                    <?php if ($p['price'] > 0): ?>
                        <?php if ($hasSale): ?>
                            <del class="old-price"><?= ms_money($p['price']) ?></del>
                            <span class="final-price"><?= ms_money($p['sale_price']) ?> <small>تومان</small></span>
                        <?php else: ?>
                            <span class="final-price"><?= ms_money($p['price']) ?> <small>تومان</small></span>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="no-price">تماس بگیرید</span>
                    <?php endif; ?>
                </div>
                <?php if ($isAvailable): ?>
                    <button class="btn-add-to-cart" onclick="addToCart(<?= (int)$p['id'] ?>, event)">افزودن به سبد خرید</button>
                <?php else: ?>
                    <button class="btn-disabled" disabled>ناموجود</button>
                <?php endif; ?>
            </div>
        </article>
        <?php
    }
}

// ============================================================
// ۱. دسته‌بندی‌ها
// ============================================================
$categories = $pdo->query("
    SELECT c.id, c.name, c.slug, COUNT(p.id) AS product_count
    FROM categories c
    LEFT JOIN products p ON p.category_id = c.id AND p.status = 1
    GROUP BY c.id
    HAVING product_count > 0
    ORDER BY product_count DESC
    LIMIT 12
")->fetchAll();

// ============================================================
// ۲. محصولات ویژه
// ============================================================
require_once 'includes/featured.php';
featured_ensure($pdo);
// اول محصولات منتخب مدیر؛ اگر مدیر چیزی انتخاب نکرده باشد، پرامتیازترین‌ها
$featuredProducts = $pdo->query("
    SELECT * FROM products
    WHERE status = 1 AND featured = 1
    ORDER BY id DESC
    LIMIT 12
")->fetchAll();
if (!$featuredProducts) $featuredProducts = $pdo->query("
    SELECT * FROM products
    WHERE status = 1 AND stock_status = 'in_stock' AND stock > 0 AND price > 0
    ORDER BY rating DESC, review_count DESC
    LIMIT 8
")->fetchAll();

// ============================================================
// ۳. جدیدترین محصولات
// ============================================================
$newestProducts = $pdo->query("
    SELECT * FROM products WHERE status = 1 ORDER BY id DESC LIMIT 8
")->fetchAll();

// ============================================================
// ۴. تخفیف‌دارها
// ============================================================
$discountProducts = $pdo->query("
    SELECT * FROM products
    WHERE status = 1 AND stock_status = 'in_stock'
      AND sale_price IS NOT NULL AND sale_price > 0 AND sale_price < price
    ORDER BY discount_percent DESC
    LIMIT 8
")->fetchAll();

// ============================================================
// ۵. آمار
// ============================================================
$totalProducts = $pdo->query("SELECT COUNT(*) FROM products WHERE status = 1")->fetchColumn();
$totalInStock  = $pdo->query("SELECT COUNT(*) FROM products WHERE status = 1 AND stock_status = 'in_stock'")->fetchColumn();
$cartCount     = array_sum($_SESSION['cart'] ?? []);


// یافتن خودکار تصاویر از پوشه icon و زیرپوشه‌های آن
if (!function_exists('ms_food_image')) {
    function ms_food_image(array $keywords = []): string {
        static $images = null;
        if ($images === null) {
            $images = [];
            $root = __DIR__ . '/icon';
            if (is_dir($root)) {
                $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
                foreach ($it as $file) {
                    if (!$file->isFile() || !in_array(strtolower($file->getExtension()), ['jpg','jpeg','png','webp','gif','avif'])) continue;
                    $rel = str_replace(DIRECTORY_SEPARATOR, '/', substr($file->getPathname(), strlen(__DIR__) + 1));
                    if (stripos($rel, 'placeholder') === false && stripos($rel, 'no-image') === false) $images[] = $rel;
                }
            }
            sort($images);
        }
        if (!$images) return 'icon/placeholder/no-image.png';
        $best = null; $scoreBest = 0;
        foreach ($images as $img) {
            $name = mb_strtolower(basename($img), 'UTF-8'); $score = 0;
            foreach ($keywords as $word) if ($word !== '' && mb_strpos($name, mb_strtolower((string)$word, 'UTF-8')) !== false) $score += 5;
            if ($score > $scoreBest) { $scoreBest = $score; $best = $img; }
        }
        return $best ?: $images[0];
    }
}
$foodHeroImage = ms_food_image(['grocery','food-basket','سبد-مواد','سوپرمارکت','مواد-غذایی','حبوبات']);
$foodFruitImage = ms_food_image(['beans','legumes','حبوبات','عدس','لوبیا','نخود','برنج']);
$foodDairyImage = ms_food_image(['dairy','milk','egg','eggs','لبنیات','شیر','تخم-مرغ','تخممرغ']);
$foodBasketImage = ms_food_image(['sugar','tea','sugar-tea','قند','شکر','چای']);
$foodMeatImage = ms_food_image(['chicken','poultry','مرغ','گوشت-مرغ']);
$foodMarketImage = ms_food_image(['grocery','shopping','market','food-basket','سبد-خرید','مواد-غذایی','سوپرمارکت']);
$foodPantryImage = ms_food_image(['rice','beans','legumes','حبوبات','برنج','عدس']);
$foodTeaImage = ms_food_image(['tea','sugar','چای','قند','شکر']);
$foodEggImage = ms_food_image(['egg','eggs','تخم-مرغ','تخممرغ']);

// تصویر بنر پایینی: فایل 005 در پوشه assets (با پشتیبانی از چند پسوند)
$bottomBannerImage = 'assets/005.jpg';
foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
    if (is_file(__DIR__ . '/assets/005.' . $ext)) {
        $bottomBannerImage = 'assets/005.' . $ext;
        break;
    }
}
$foodChickenImage = ms_food_image(['chicken','poultry','مرغ']);
$foodLambImage = ms_food_image(['lamb','mutton','sheep','گوشت-گوسفند','گوسفند']);
$catIcons = ['🍎','🥬','🥛','🥩','🍞','🧀','🥤','🍫','🍚','🧴','🧊','🥫'];

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars(SITE_NAME) ?> | فروشگاه آنلاین مواد غذایی</title>
<meta name="description" content="خرید آنلاین مواد غذایی تازه، میوه، سبزیجات، لبنیات و محصولات سوپرمارکتی با قیمت مناسب">
<link rel="preconnect" href="https://cdn.jsdelivr.net">
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
<style>
:root{
    --navy:#1b2a41;
    --navy-deep:#111c2d;
    --navy-soft:#2a3d5c;
    --gold:#b8923a;
    --gold-light:#d9b968;
    --gold-pale:#f4ead2;
    --burgundy:#7a1f2b;
    --cream:#faf7f2;
    --paper:#ffffff;
    --ink:#22262e;
    --muted:#6b7280;
    --line:#e6dfd0;
    --green:#2f6b4f;
    --shadow:0 2px 10px rgba(27,42,65,.07);
    --shadow-hover:0 14px 30px -10px rgba(27,42,65,.28);
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{
    font-family:'Vazirmatn',tahoma,sans-serif;
    background:var(--cream);
    color:var(--ink);
    line-height:1.7;
    -webkit-font-smoothing:antialiased;
}
a{text-decoration:none;color:inherit;transition:color .2s,background .2s,border-color .2s}
img{max-width:100%;display:block}
button{font-family:inherit;cursor:pointer;border:none;outline:none}
ul{list-style:none}
.container{max-width:1280px;margin:0 auto;padding:0 24px}

/* ============ Hero (بنر اصلی + دو کارت کناری) ============ */
.hero-grid{display:grid;grid-template-columns:2fr 1fr;gap:18px;margin:22px 0 10px}
.hero-main{position:relative;overflow:hidden;border-radius:22px;padding:56px 48px;min-height:380px;display:flex;flex-direction:column;justify-content:center;
    color:#fff;background:radial-gradient(circle at 15% 85%,rgba(255,255,255,.07),transparent 45%),linear-gradient(135deg,var(--navy-deep),var(--navy));
    box-shadow:0 22px 40px -22px rgba(15,23,42,.6)}
.hero-main::before{content:'';position:absolute;inset:0;background-image:radial-gradient(rgba(255,255,255,.09) 1.2px,transparent 1.2px);background-size:22px 22px;pointer-events:none}
.hero-main>*{position:relative}
.hero-wm{position:absolute!important;left:34px;bottom:10px;font-size:210px;line-height:1;filter:grayscale(1) brightness(1.6);opacity:.14;pointer-events:none}
.hero-badge{align-self:flex-start;background:var(--gold);color:#fff;font-size:12px;font-weight:800;padding:6px 16px;border-radius:999px;margin-bottom:20px}
.hero-main h1{font-size:40px;font-weight:900;line-height:1.5;margin:0}
.hero-main h1 em{display:block;font-style:normal;color:var(--gold)}
.hero-main p{font-size:15px;color:#cbd5e1;margin:14px 0 26px;max-width:560px}
.hero-btns{display:flex;gap:12px;flex-wrap:wrap}
.hb{padding:13px 28px;border-radius:12px;font-size:14px;font-weight:800;transition:transform .2s}
.hb:hover{transform:translateY(-2px)}
.hb-1{background:var(--gold);color:#fff;box-shadow:0 12px 24px -10px var(--gold)}
.hb-2{border:1px solid rgba(255,255,255,.28);color:#fff;background:rgba(255,255,255,.04)}
.hero-side{display:grid;grid-template-rows:1fr 1fr;gap:18px}
.hs{position:relative;overflow:hidden;border-radius:22px;padding:26px 28px;display:flex;flex-direction:column;justify-content:space-between;min-height:180px;color:#fff;box-shadow:0 18px 34px -22px rgba(15,23,42,.6)}
.hs-1{background:linear-gradient(135deg,var(--gold-light),var(--gold-deep,var(--gold)))}
.hs-2{background:linear-gradient(135deg,var(--navy-deep),var(--navy))}
.hs-tag{align-self:flex-start;background:rgba(255,255,255,.22);font-size:11px;font-weight:700;padding:4px 12px;border-radius:8px}
.hs-2 .hs-tag{background:var(--gold)}
.hs h3{font-size:21px;font-weight:900;margin:10px 0 2px;line-height:1.4}
.hs p{font-size:12px;opacity:.85;margin:0}
.hs-go{font-size:13px;font-weight:800;border-bottom:1px solid currentColor;align-self:flex-start;padding-bottom:1px}
.hs-2 .hs-go{color:var(--gold)}
.hs-wm{position:absolute;left:18px;bottom:6px;font-size:96px;line-height:1;filter:grayscale(1) brightness(2);opacity:.16;pointer-events:none}
.hs>div,.hs>a{position:relative}
.hero-coupons{margin:30px 0 0;max-width:none}
.hc-title{font-size:12.5px;color:var(--gold-light);margin-bottom:10px}
.hc-list{display:flex;flex-wrap:wrap;gap:10px}
.hc{position:relative;overflow:hidden;min-width:170px;padding:12px 20px 12px 20px;border-radius:14px;color:#fff;text-align:center;border:2px dashed rgba(255,255,255,.65);
    box-shadow:0 10px 24px -8px rgba(0,0,0,.45);cursor:pointer;font-family:inherit;transition:transform .2s}
.hc:hover{transform:translateY(-3px) rotate(-.6deg)}
.hc::after{content:'';position:absolute;top:0;left:-60%;width:40%;height:100%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.35),transparent);transform:skewX(-20deg);animation:hcshine 3.6s infinite}
@keyframes hcshine{0%{left:-60%}60%,100%{left:130%}}
.hc .hc-val{display:block;font-size:19px;font-weight:800;text-shadow:0 1px 3px rgba(0,0,0,.3)}
.hc .hc-code{display:inline-block;margin:6px 0 3px;background:rgba(255,255,255,.92);color:#222;padding:3px 14px;border-radius:8px;font-family:Consolas,monospace;font-size:16px;letter-spacing:2px;font-weight:800}
.hc small{display:block;font-size:11.5px;opacity:.95}
.hc-0{background:linear-gradient(135deg,#ff416c,#ff8a00)}
.hc-1{background:linear-gradient(135deg,#00b4db,#0083b0 55%,#6a11cb)}
.hc-2{background:linear-gradient(135deg,#11998e,#38ef7d)}
.hc-3{background:linear-gradient(135deg,#8e2de2,#f64f9b)}
.hc-ok{outline:3px solid #fff}

/* ============ بخش‌ها ============ */
.section{margin:56px 0}
.section-header{text-align:center;margin-bottom:30px;position:relative}
.section-header h2{
    display:inline-block;font-size:24px;font-weight:800;color:var(--navy);
    position:relative;padding:0 24px;
}
.section-header .divider{
    display:flex;align-items:center;justify-content:center;gap:12px;margin-top:8px;color:var(--gold);
}
.section-header .divider::before,.section-header .divider::after{
    content:'';height:1px;width:80px;
    background:linear-gradient(90deg,transparent,var(--gold));
}
.section-header .divider::after{background:linear-gradient(270deg,transparent,var(--gold))}
.section-header .divider span{font-size:12px}
.section-more{text-align:center;margin-top:28px}
.section-more a{
    display:inline-block;padding:10px 30px;border:1.5px solid var(--navy);
    color:var(--navy);font-weight:700;font-size:13px;border-radius:3px;
}
.section-more a:hover{background:var(--navy);color:var(--gold-light)}

/* ============ دسته‌بندی ============ */
.categories-grid{
    display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:18px;
}
.category-card{
    background:var(--paper);border:1px solid var(--line);border-radius:6px;
    padding:28px 14px 22px;text-align:center;position:relative;
    transition:all .3s;box-shadow:var(--shadow);
}
.category-card::after{
    content:'';position:absolute;bottom:0;right:50%;transform:translateX(50%);
    width:0;height:3px;background:var(--gold);transition:width .3s;
}
.category-card:hover{transform:translateY(-5px);box-shadow:var(--shadow-hover);border-color:var(--gold-light)}
.category-card:hover::after{width:60%}
.category-card .icon{
    width:62px;height:62px;margin:0 auto 14px;border-radius:50%;
    display:grid;place-items:center;font-size:28px;
    background:var(--gold-pale);border:1px solid var(--gold-light);
}
.category-card .name{font-size:14px;font-weight:700;color:var(--navy);margin-bottom:2px}
.category-card .count{font-size:12px;color:var(--muted)}

/* ============ محصولات ============ */
.products-grid{
    display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:22px;
}
.product-card{
    background:var(--paper);border:1px solid var(--line);border-radius:6px;
    overflow:hidden;position:relative;display:flex;flex-direction:column;
    transition:all .3s;box-shadow:var(--shadow);
}
.product-card:hover{transform:translateY(-6px);box-shadow:var(--shadow-hover);border-color:var(--gold-light)}
.product-card.out-of-stock{opacity:.88}
.product-card.out-of-stock .product-image img{filter:grayscale(70%)}
.ribbon{
    position:absolute;top:14px;right:0;z-index:5;
    color:#fff;font-size:11.5px;font-weight:700;
    padding:4px 14px 4px 12px;
    clip-path:polygon(0 0,100% 0,100% 100%,0 100%,8px 50%);
    padding-right:18px;
}
.ribbon-sale{background:var(--burgundy)}
.ribbon-off{background:#6b7280}
.product-image{
    display:block;background:#fcfbf8;padding:22px;text-align:center;
    border-bottom:1px solid var(--line);overflow:hidden;
}
.product-image img{
    width:100%;height:190px;object-fit:contain;transition:transform .4s;
}
.product-card:hover .product-image img{transform:scale(1.06)}
.product-info{padding:16px;flex:1;display:flex;flex-direction:column}
.product-title{
    font-size:13.5px;line-height:1.8;font-weight:600;
    height:50px;overflow:hidden;margin-bottom:12px;
}
.product-title a{color:var(--navy)}
.product-title a:hover{color:var(--gold)}
.product-price{margin-top:auto;min-height:56px;display:flex;flex-direction:column;justify-content:flex-end}
.old-price{color:#9a9486;font-size:12.5px;text-decoration:line-through}
.final-price{font-size:18px;font-weight:800;color:var(--navy)}
.final-price small{font-size:11.5px;color:var(--muted);font-weight:500}
.no-price{color:var(--burgundy);font-size:13px;font-weight:700}
.btn-add-to-cart{
    width:100%;margin-top:14px;padding:11px;border-radius:3px;
    background:var(--navy);color:var(--gold-light);
    font-size:13px;font-weight:700;border:1px solid var(--navy);
    transition:all .25s;
}
.btn-add-to-cart:hover{background:var(--gold);border-color:var(--gold);color:#fff}
.btn-disabled{
    width:100%;margin-top:14px;padding:11px;border-radius:3px;
    background:#eceae4;color:#9a9486;font-size:13px;font-weight:700;cursor:not-allowed;
}

/* ============ فوتر ============ */
.site-footer{
    background:var(--navy-deep);color:#b6bfce;
    margin-top:80px;border-top:4px solid var(--gold);
}
.footer-main{padding:52px 0 28px}
.footer-grid{
    display:grid;grid-template-columns:1.4fr 1fr 1fr 1.2fr;gap:40px;
}
.footer-col h4{
    color:#fff;font-size:15px;font-weight:700;margin-bottom:18px;
    padding-bottom:10px;position:relative;
}
.footer-col h4::after{
    content:'';position:absolute;bottom:0;right:0;width:36px;height:2px;background:var(--gold);
}
.footer-col p{font-size:13px;line-height:2;color:#97a2b6}
.footer-col li{margin-bottom:10px;font-size:13px}
.footer-col a{color:#97a2b6}
.footer-col a:hover{color:var(--gold-light)}
.footer-bottom{
    border-top:1px solid #243248;text-align:center;
    padding:18px 0;font-size:12.5px;color:#7d889c;
}

/* ============ Toast ============ */
.toast{
    position:fixed;bottom:30px;left:50%;
    transform:translateX(-50%) translateY(100px);
    padding:13px 28px;border-radius:4px;font-size:14px;font-weight:600;color:#fff;
    box-shadow:0 14px 30px -8px rgba(0,0,0,.35);
    z-index:9999;opacity:0;transition:all .4s;
    border-bottom:3px solid var(--gold);
}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
.toast.success{background:var(--navy)}
.toast.error{background:var(--burgundy)}

/* ============ ریسپانسیو ============ */
@media(max-width:992px){
    .footer-grid{grid-template-columns:1fr 1fr}
}
@media(max-width:768px){
    .container{padding:0 16px}
    .section{margin:40px 0}
    .section-header h2{font-size:20px}
    .products-grid{grid-template-columns:repeat(2,1fr);gap:12px}
    .product-image{padding:12px}
    .product-image img{height:130px}
    .product-info{padding:12px}
    .product-title{font-size:12.5px;height:46px}
    .final-price{font-size:15px}
    .categories-grid{grid-template-columns:repeat(2,1fr);gap:12px}
    .footer-grid{grid-template-columns:1fr;gap:28px}
}
@media(max-width:900px){
    .hero-grid{grid-template-columns:1fr}
    .hero-main{padding:34px 24px;min-height:300px}
    .hero-main h1{font-size:27px}
    .hero-wm{font-size:120px}
    .hero-side{grid-template-rows:none;grid-template-columns:1fr 1fr}
}
@media(max-width:560px){ .hero-side{grid-template-columns:1fr} }
@media(max-width:400px){
    .products-grid{grid-template-columns:1fr}
}

/* ============ طراحی فروشگاه مواد غذایی ============ */
:root{--navy:#174b35;--navy-deep:#103a2a;--navy-soft:#286b4c;--gold:#f2a900;--gold-light:#ffd166;--gold-pale:#fff3d2;--burgundy:#e45b36;--cream:#f7faf5;--line:#e4ecdf;--green:#23834d;--shadow:0 5px 22px rgba(27,75,48,.08);--shadow-hover:0 16px 34px rgba(27,75,48,.16)}
body{background:#f7faf5}.container{max-width:1320px}
.hero-grid{grid-template-columns:1.75fr 1fr;gap:20px;margin-top:26px}
.hero-main{min-height:420px;padding:52px 48px;border-radius:28px;background:linear-gradient(100deg,rgba(12,53,35,.97),rgba(18,75,49,.86) 48%,rgba(18,75,49,.2)),#174b35}
.hero-food-photo{position:absolute!important;left:0;top:0;width:58%;height:100%;object-fit:cover;opacity:.9;z-index:0;mask-image:linear-gradient(to left,#000 55%,transparent 100%)}
.hero-main>*:not(.hero-food-photo){z-index:2}.hero-main h1{font-size:clamp(28px,3vw,43px);max-width:620px}.hero-main h1 em{color:#ffd166}
.hero-main p{max-width:510px;font-size:16px;line-height:2;color:#edf7ed}.hero-badge{background:#f2a900;color:#263b2d}
.hb{border-radius:30px}.hb-1{background:#f2a900;color:#183b29}.hb-2{border-color:rgba(255,255,255,.55);background:rgba(255,255,255,.1)}
.hero-side{gap:20px}.hs{border-radius:24px;min-height:195px;padding:24px 26px}
.hs-1{background:linear-gradient(110deg,rgba(208,111,28,.96),rgba(242,169,0,.72))}.hs-2{background:linear-gradient(110deg,rgba(20,78,51,.98),rgba(36,126,75,.7))}
.side-food-photo{position:absolute;left:0;top:0;width:58%;height:100%;object-fit:cover;opacity:.72;mask-image:linear-gradient(to left,#000 35%,transparent 100%)}
.hs>div,.hs>a,.hs-tag{z-index:2}.hs h3{font-size:22px;max-width:65%}.hs p{max-width:65%;line-height:1.8}.hs-go{border:0}
.hero-coupons{position:relative;z-index:3}.hc{border-radius:14px}
.section{margin:58px 0}.section-header h2{color:#174b35}.section-header .divider{color:#f2a900}
.section-header .divider::before,.section-header .divider::after{background:linear-gradient(90deg,transparent,#f2a900)}
.categories-grid{grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:16px}
.category-card{border:1px solid #e5eddf;border-radius:18px;padding:22px 12px 18px;box-shadow:0 4px 16px rgba(28,75,48,.05);background:#fff}
.category-card .icon{width:88px;height:88px;border-radius:22px;background:#f4f8ef;border:1px solid #e5eddf;padding:8px;overflow:hidden;position:relative}
.category-card .icon img{width:100%;height:100%;object-fit:contain;border-radius:16px;position:relative;z-index:2}
.category-card .icon-fallback{position:absolute;inset:0;display:grid;place-items:center;font-size:35px}
.category-card .name{font-size:14px;margin-top:5px}.category-card:hover{border-color:#a8d5ac}
.products-grid{grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:20px}
.product-card{border-radius:18px;border-color:#e7eee3}.product-image{background:#fbfdf9;padding:18px;border-bottom:1px solid #edf2e9}
.product-image img{height:190px;object-fit:contain}.product-info{padding:17px}.product-title a{color:#214d35}.final-price{color:#16804b}
.btn-add-to-cart{border-radius:12px;background:#21834d;color:#fff;border:0}.btn-add-to-cart:hover{background:#f2a900;color:#173c29}
.ribbon-sale{background:#e85d3f;border-radius:0 0 0 10px}.section-more a{border-radius:24px;border-color:#21834d;color:#21834d}
.section-more a:hover{background:#21834d;color:#fff}.site-footer{border-top:5px solid #f2a900}.toast{border-radius:14px}
@media(max-width:900px){.hero-grid{grid-template-columns:1fr}.hero-main{min-height:390px;padding:36px 26px}.hero-food-photo{width:75%;opacity:.48}.hero-side{grid-template-columns:1fr 1fr}}
@media(max-width:560px){.hero-side{grid-template-columns:1fr}.hero-main{min-height:420px;padding:30px 22px}.hero-main h1{font-size:27px}.hero-food-photo{width:100%;opacity:.28}.hero-coupons{margin-top:22px}.hc{min-width:calc(50% - 6px);padding:10px}.hc .hc-val{font-size:16px}.categories-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.products-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:380px){.products-grid{grid-template-columns:1fr}}



/* ===== Fresh Market premium visual refresh ===== */
:root{
 --fresh-green:#176b45;--fresh-deep:#10452f;--fresh-lime:#d9efbd;
 --fresh-orange:#ffad32;--fresh-cream:#fffdf7;--fresh-ink:#24352b;
 --fresh-muted:#78857a;--fresh-line:#e8eee4;
}
body{background:linear-gradient(180deg,#f7fbf4 0%,#fffdf8 44%,#f8fbf5 100%);color:var(--fresh-ink)}
.container{max-width:1380px;padding-left:28px;padding-right:28px}
.fresh-benefits{background:#fff;border-bottom:1px solid #edf2e9;box-shadow:0 5px 20px rgba(29,76,48,.035)}
.fresh-benefits-inner{max-width:1324px;margin:auto;padding:14px 28px;display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.benefit-item{display:flex;align-items:center;gap:12px;justify-content:center;min-height:54px}
.benefit-icon{width:44px;height:44px;display:grid;place-items:center;border-radius:15px;background:#eff8e9;font-size:23px}
.benefit-item b{display:block;color:#24583a;font-size:13px;font-weight:900}
.benefit-item small{display:block;color:#89958a;font-size:10.5px;margin-top:1px}
.hero-grid{margin:30px 0 12px;grid-template-columns:minmax(0,1.7fr) minmax(270px,.85fr);gap:22px}
.hero-main{min-height:450px;padding:54px 54px;border-radius:32px;background:linear-gradient(100deg,rgba(8,54,34,.98) 0%,rgba(16,77,48,.91) 48%,rgba(18,77,48,.22) 100%),#155b3a;box-shadow:0 22px 55px rgba(24,86,50,.18)}
.hero-main:after{content:"";position:absolute;inset:auto -80px -160px auto;width:360px;height:360px;border:1px solid rgba(255,255,255,.12);border-radius:50%;box-shadow:0 0 0 35px rgba(255,255,255,.035),0 0 0 75px rgba(255,255,255,.025);pointer-events:none}
.hero-food-photo{width:62%;object-fit:cover;opacity:.95;mask-image:linear-gradient(to left,#000 45%,transparent 100%)}
.hero-badge{background:#ffbd4a;color:#28452f;border-radius:30px;padding:7px 17px;box-shadow:0 6px 18px rgba(0,0,0,.12)}
.hero-main h1{font-size:clamp(30px,3.25vw,47px);line-height:1.55;letter-spacing:-.7px;text-shadow:0 2px 12px rgba(0,0,0,.12)}
.hero-main h1 em{color:#ffe08b}
.hero-main p{font-size:15px;line-height:2.15;color:#eff8ef;max-width:500px}
.hb{padding:13px 25px;border-radius:15px;box-shadow:0 8px 22px rgba(0,0,0,.1)}
.hb-1{background:linear-gradient(135deg,#ffd36d,#ffae32);color:#28432f}
.hb-2{background:rgba(255,255,255,.12);backdrop-filter:blur(8px)}
.hero-side{gap:22px}
.hs{min-height:205px;border-radius:27px;padding:25px 26px;box-shadow:0 14px 35px rgba(32,71,43,.13)}
.hs-1{background:linear-gradient(110deg,rgba(177,91,22,.94),rgba(244,166,42,.72))}
.hs-2{background:linear-gradient(110deg,rgba(13,74,47,.98),rgba(41,130,77,.78))}
.side-food-photo{position:absolute;left:0;top:0;width:59%;height:100%;object-fit:cover;opacity:.58;mask-image:linear-gradient(to left,#000 30%,transparent 100%);z-index:0}
.hs>div,.hs>a{z-index:2}.hs h3{font-size:22px;text-shadow:0 2px 8px rgba(0,0,0,.13)}
.hs-tag{border-radius:30px;padding:5px 13px;background:rgba(255,255,255,.25)}
.hs-go{border:0;background:rgba(255,255,255,.17);padding:7px 13px;border-radius:10px}
.hero-coupons{margin-top:25px}.hc{border-radius:14px;min-width:155px;padding:9px 14px}
.section{margin:66px 0}
.section-header{margin-bottom:28px}
.section-header h2{font-size:25px;color:#20563a;padding:0 16px}
.section-header .divider{color:#e8a52e}.section-header .divider span{font-size:15px}
.section-header .divider:before,.section-header .divider:after{width:105px;background:linear-gradient(90deg,transparent,#d9e7d4)}
.categories-grid{grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:18px}
.category-card{border:1px solid #e9efe5;border-radius:23px;padding:20px 12px 18px;background:rgba(255,255,255,.94);box-shadow:0 8px 25px rgba(40,83,49,.055);overflow:hidden}
.category-card:before{content:"";position:absolute;inset:0;background:linear-gradient(145deg,rgba(232,247,224,.4),transparent 55%);pointer-events:none}
.category-card .icon{width:92px;height:92px;border-radius:27px;background:linear-gradient(145deg,#f5faef,#eaf5e3);border:1px solid #e2eddb;box-shadow:inset 0 2px 8px rgba(255,255,255,.9);margin-bottom:12px}
.category-card .icon img{object-fit:contain;padding:4px}.category-card .icon-fallback{z-index:1;pointer-events:none}
.category-card .name{font-size:14px;font-weight:850;color:#28573a}.category-card .count{font-size:11px;color:#8a998b}
.category-card:hover{transform:translateY(-7px);border-color:#b9d8ad;box-shadow:0 16px 32px rgba(40,100,53,.12)}
.category-card:hover:after{width:52%;height:4px;border-radius:10px;background:#f3b33e}
.products-grid{grid-template-columns:repeat(auto-fill,minmax(225px,1fr));gap:20px}
.product-card{border:1px solid #e8eee4;border-radius:22px;background:#fff;box-shadow:0 7px 23px rgba(36,75,44,.055)}
.product-card:hover{transform:translateY(-7px);border-color:#c7dfbd;box-shadow:0 18px 35px rgba(34,92,48,.13)}
.product-image{background:radial-gradient(circle at 50% 45%,#fff 0,#f8fbf5 72%);padding:20px;border-bottom:1px solid #edf2e9}
.product-image img{height:195px;transition:transform .45s}
.product-card:hover .product-image img{transform:scale(1.09)}
.product-info{padding:17px 18px 19px}.product-title{height:48px;font-size:13px;line-height:1.9}
.product-title a{color:#315b3d}.final-price{font-size:19px;color:#18834b}.final-price small{color:#879487}
.old-price{color:#a2aaa0}.btn-add-to-cart{border-radius:13px;padding:12px;background:linear-gradient(135deg,#238b50,#176c40);box-shadow:0 6px 14px rgba(35,139,80,.16)}
.btn-add-to-cart:hover{background:linear-gradient(135deg,#f5b53e,#ed9822);color:#24432e;transform:translateY(-1px)}
.btn-disabled{border-radius:13px}
.ribbon{border-radius:0 0 0 13px;padding:6px 14px}.ribbon-sale{background:#ed644b}
.section-more a{border:1px solid #cfe1c8;border-radius:30px;padding:11px 30px;color:#24643e;background:#fff;box-shadow:0 5px 15px rgba(35,91,49,.05)}
.section-more a:hover{background:#1e7b49;border-color:#1e7b49;color:#fff}
.site-footer{background:radial-gradient(circle at 15% 0%,#225b3c,#103a29 58%);border-top:5px solid #f2b33f;margin-top:90px}
.footer-main{padding:58px 0 32px}.footer-col h4{font-size:15px}.footer-col p,.footer-col li{line-height:2.1}
.toast{border-radius:15px;background:#175b39;border-bottom:0}
@media(max-width:900px){.hero-grid{grid-template-columns:1fr}.hero-main{min-height:400px}.hero-side{grid-template-columns:1fr 1fr}.fresh-benefits-inner{grid-template-columns:repeat(2,1fr)}}
@media(max-width:600px){.container{padding:0 14px}.fresh-benefits-inner{padding:10px 12px;gap:8px}.benefit-item{justify-content:flex-start;gap:8px}.benefit-icon{width:37px;height:37px;font-size:19px;border-radius:12px}.benefit-item b{font-size:11px}.benefit-item small{font-size:9px}.hero-main{padding:30px 22px;min-height:410px;border-radius:24px}.hero-food-photo{width:100%;opacity:.32;mask-image:linear-gradient(to left,#000 0%,transparent 100%)}.hero-main h1{font-size:28px}.hero-main p{font-size:13px}.hero-side{grid-template-columns:1fr;gap:13px}.hs{min-height:170px}.section{margin:48px 0}.section-header h2{font-size:21px}.categories-grid{gap:11px}.category-card{padding:15px 8px;border-radius:18px}.category-card .icon{width:76px;height:76px;border-radius:22px}.products-grid{gap:11px;grid-template-columns:repeat(2,minmax(0,1fr))}.product-card{border-radius:16px}.product-image{padding:10px}.product-image img{height:125px}.product-info{padding:11px}.product-title{font-size:11.5px;height:43px}.final-price{font-size:14px}.btn-add-to-cart{font-size:11px;padding:10px 5px}}
@media(max-width:370px){.products-grid{grid-template-columns:1fr}}


/* ===== Reference-inspired Fresh Grocery homepage ===== */
:root{--fresh-green:#176b4a;--fresh-dark:#123c2d;--fresh-orange:#ffb52e;--fresh-text:#172b22}
body{background:#f5f6f4;color:var(--fresh-text)}
.container{max-width:1320px;padding-inline:22px}
.fresh-hero{position:relative;isolation:isolate;overflow:hidden;min-height:320px;margin:26px 0 22px;border-radius:25px;background:linear-gradient(105deg,#d9f1f7 0%,#eaf8f7 52%,#d8f0f5 100%);display:grid;grid-template-columns:1fr 1.05fr;align-items:center;padding:28px 44px;box-shadow:0 10px 30px rgba(36,91,75,.06)}
.fresh-hero-copy{position:relative;z-index:2}.fresh-kicker{display:inline-block;background:#fff;border:1px solid #d8ebdf;color:#26734d;border-radius:30px;padding:6px 15px;font-size:12px;font-weight:800}.fresh-hero h1{font-size:clamp(30px,3.3vw,45px);line-height:1.45;color:#163b2c;margin:12px 0}.fresh-hero h1 strong{color:#218653}.fresh-hero p{font-size:14px;line-height:2;color:#52675b;max-width:430px;margin-bottom:17px}.fresh-hero-btn{display:inline-flex;align-items:center;gap:20px;background:#173d2e;color:#fff;padding:11px 19px;border-radius:30px;font-size:13px;font-weight:800;box-shadow:0 7px 16px #173d2e22}.fresh-hero-btn span{font-size:18px}.fresh-hero-note{font-size:11px;color:#557163;margin-top:17px;display:flex;gap:9px;align-items:center}.fresh-hero-note span{color:#218653;font-weight:900}.fresh-hero-art{height:270px;display:flex;align-items:center;justify-content:center;position:relative;z-index:1}.fresh-hero-art img{width:100%;height:100%;object-fit:contain;mix-blend-mode:multiply}.fresh-deco{position:absolute;z-index:0;opacity:.18;font-size:65px}.fresh-deco-one{right:10px;bottom:8px}.fresh-deco-two{left:42%;top:8px}
.promo-trio{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:17px;margin:20px 0 48px}.promo-tile{position:relative;overflow:hidden;min-height:170px;border-radius:18px;padding:18px 20px;display:flex;flex-direction:column;align-items:flex-start;box-shadow:0 8px 20px rgba(25,60,40,.06);transition:.25s}.promo-tile:hover{transform:translateY(-4px);box-shadow:0 14px 26px rgba(25,60,40,.12)}.promo-green{background:linear-gradient(120deg,#0f7250,#42a77b);color:#fff}.promo-pink{background:linear-gradient(120deg,#f6d9df,#f5a9b8);color:#532b38}.promo-yellow{background:linear-gradient(120deg,#fff3a8,#ffdc4c);color:#463b12}.promo-label{font-size:10px;font-weight:900;letter-spacing:.2px;background:#ffffff35;padding:5px 9px;border-radius:20px}.promo-tile h3{font-size:17px;line-height:1.55;margin:9px 0 3px;max-width:65%;font-weight:900}.promo-tile p{font-size:10px;opacity:.85;max-width:65%}.promo-tile img{position:absolute;left:4px;bottom:3px;width:44%;height:82%;object-fit:contain;mix-blend-mode:multiply}.promo-arrow{position:absolute;right:17px;bottom:13px;width:25px;height:25px;border-radius:50%;display:grid;place-items:center;background:#173d2e;color:#fff;font-size:14px}
.section{margin:48px 0}.section-header{text-align:right;margin-bottom:18px}.section-header h2{font-size:21px;color:#182c22;padding:0;font-weight:900}.section-header .divider{display:none}.section-header:after{content:'';display:block;width:44px;height:3px;background:#29925b;border-radius:5px;margin-top:7px}.products-grid{grid-template-columns:repeat(5,minmax(0,1fr));gap:14px}.product-card{border:1px solid #ecefec;border-radius:14px;box-shadow:0 4px 14px rgba(30,55,38,.045);min-width:0}.product-card:hover{transform:translateY(-4px)}.product-image{padding:10px;background:#fff;border-bottom:0}.product-image img{height:118px;object-fit:contain}.product-info{padding:10px 12px 12px}.product-title{font-size:11px;height:39px;line-height:1.7;margin-bottom:5px}.final-price{font-size:14px;color:#1b7650}.product-price{min-height:40px}.btn-add-to-cart{font-size:10px;padding:8px 5px;border-radius:20px;background:#176b4a}.section-more{text-align:left;margin-top:14px}.section-more a{padding:7px 16px;font-size:11px;border-radius:22px;background:#fff;border-color:#dfe9df;color:#376c4b}
.fresh-bottom-banner{position:relative;overflow:hidden;min-height:250px;border-radius:22px;background:linear-gradient(105deg,#ccecf5,#dff5f4 60%,#d3edf0);margin:55px 0 12px;padding:32px 38px;display:flex;align-items:center}.bottom-banner-copy{position:relative;z-index:2;max-width:50%}.bottom-banner-copy>span{font-size:12px;color:#27734e;font-weight:900}.bottom-banner-copy h2{font-size:27px;line-height:1.5;color:#163b2c;margin:7px 0}.bottom-banner-copy p{font-size:11px;color:#50695d;line-height:1.9}.bottom-banner-copy a{display:inline-flex;gap:15px;align-items:center;margin-top:12px;padding:9px 16px;border-radius:25px;background:#173d2e;color:white;font-size:11px;font-weight:800}.fresh-bottom-banner>img{position:absolute;left:0;bottom:-5px;width:58%;height:110%;object-fit:contain;object-position:left bottom;mix-blend-mode:multiply}
.site-footer{margin-top:55px}
@media(max-width:900px){.fresh-hero{grid-template-columns:1fr 1fr;padding:25px}.fresh-hero-art{height:220px}.products-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.promo-tile{min-height:155px}}
@media(max-width:620px){.container{padding-inline:13px}.fresh-hero{grid-template-columns:1fr;min-height:0;padding:22px 20px;margin-top:16px}.fresh-hero-art{height:165px;grid-row:1}.fresh-hero-copy{grid-row:2}.fresh-hero h1{font-size:29px}.fresh-hero p{font-size:12px}.fresh-hero-note{font-size:9px}.promo-trio{grid-template-columns:1fr;gap:10px;margin-bottom:35px}.promo-tile{min-height:140px}.promo-tile h3{font-size:16px}.promo-tile img{width:39%;height:90%}.section{margin:38px 0}.section-header h2{font-size:18px}.products-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.product-image img{height:105px}.product-info{padding:9px}.product-title{font-size:10px;height:38px}.final-price{font-size:12px}.btn-add-to-cart{font-size:9px}.fresh-bottom-banner{min-height:300px;padding:23px 20px;align-items:flex-start}.bottom-banner-copy{max-width:100%}.bottom-banner-copy h2{font-size:23px}.bottom-banner-copy p{max-width:70%}.fresh-bottom-banner>img{width:85%;height:65%;opacity:.95}.footer-grid{grid-template-columns:1fr}}



/* ===== Premium campaign banners: polished grocery storefront ===== */
.fresh-hero{
  min-height:370px; margin:30px 0 26px; padding:34px 48px;
  border:1px solid rgba(255,255,255,.9); border-radius:30px;
  background:radial-gradient(circle at 13% 20%,rgba(255,255,255,.95),transparent 27%),
             radial-gradient(circle at 82% 90%,rgba(183,226,194,.55),transparent 32%),
             linear-gradient(115deg,#d8f1e4 0%,#eaf7ef 48%,#fff5dc 100%);
  box-shadow:0 18px 48px rgba(37,100,62,.11),inset 0 1px 0 #fff;
  isolation:isolate;
}
.fresh-hero:before{content:"";position:absolute;z-index:-1;width:290px;height:290px;left:30%;top:-190px;border:1px solid rgba(36,119,72,.12);border-radius:50%;box-shadow:0 0 0 28px rgba(255,255,255,.16),0 0 0 58px rgba(255,255,255,.12)}
.fresh-hero:after{content:"تازگیِ هر روز";position:absolute;left:28px;bottom:22px;color:rgba(30,111,67,.12);font-size:clamp(22px,3vw,38px);font-weight:1000;letter-spacing:-1px;transform:rotate(-8deg);pointer-events:none}
.fresh-hero-copy{max-width:570px;padding:8px 0}
.fresh-kicker{background:rgba(255,255,255,.82);border:1px solid #cfe7d5;color:#176b45;padding:7px 16px;box-shadow:0 5px 14px rgba(37,100,62,.06)}
.fresh-hero h1{font-size:clamp(34px,3.6vw,50px);line-height:1.42;letter-spacing:-1.2px;margin:15px 0 12px;color:#173e2b}
.fresh-hero h1 strong{color:#218653;text-shadow:0 5px 18px rgba(33,134,83,.12)}
.fresh-hero p{font-size:14px;line-height:2.15;color:#526b5a;max-width:455px;margin-bottom:20px}
.fresh-hero-btn{padding:13px 22px;border-radius:14px;background:linear-gradient(135deg,#238b55,#12623e);box-shadow:0 10px 22px rgba(23,107,69,.23);transition:transform .25s,box-shadow .25s}
.fresh-hero-btn:hover{transform:translateY(-3px);box-shadow:0 15px 28px rgba(23,107,69,.28);color:#fff}
.fresh-hero-note{gap:10px;color:#52745d;font-weight:650}
.fresh-hero-note span:first-child{width:18px;height:18px;border-radius:50%;display:inline-grid;place-items:center;background:#d9f1df;color:#16814c}
.fresh-hero-art{height:315px;position:relative;filter:drop-shadow(0 20px 22px rgba(47,91,48,.16))}
.fresh-hero-art:before{content:"";position:absolute;width:76%;height:76%;left:12%;top:13%;border-radius:50%;background:radial-gradient(circle,#fff 0%,rgba(255,255,255,.5) 50%,transparent 72%);z-index:-1}
.fresh-hero-art img{width:100%;height:100%;object-fit:contain;mix-blend-mode:multiply;transform:scale(1.08);transition:transform .5s}
.fresh-hero:hover .fresh-hero-art img{transform:scale(1.13) rotate(-1deg)}
.fresh-deco{opacity:.22;filter:saturate(1.1)}
.fresh-deco-one{right:22px;bottom:18px}.fresh-deco-two{left:45%;top:15px}

.promo-trio{gap:20px;margin:24px 0 52px}
.promo-tile{min-height:190px;padding:21px 22px;border-radius:23px;border:1px solid rgba(255,255,255,.72);box-shadow:0 12px 28px rgba(38,76,48,.09);isolation:isolate}
.promo-tile:before{content:"";position:absolute;inset:0;z-index:0;background:linear-gradient(100deg,rgba(0,0,0,.04),transparent 65%);pointer-events:none}
.promo-tile:after{content:"";position:absolute;z-index:0;width:165px;height:165px;left:-42px;bottom:-90px;border:1px solid rgba(255,255,255,.36);border-radius:50%;box-shadow:0 0 0 18px rgba(255,255,255,.08),0 0 0 38px rgba(255,255,255,.055);pointer-events:none}
.promo-green{background:linear-gradient(125deg,#08744e 0%,#159566 58%,#8ccf86 100%);color:#fff}
.promo-pink{background:linear-gradient(125deg,#f9dce0 0%,#f7b8bd 55%,#ef8f9c 100%);color:#542c38}
.promo-yellow{background:linear-gradient(125deg,#fff5c7 0%,#ffe58a 55%,#ffc64b 100%);color:#4c3a13}
.promo-label{position:relative;z-index:2;padding:6px 11px;border:1px solid rgba(255,255,255,.24);backdrop-filter:blur(8px);font-size:10px}
.promo-tile h3{position:relative;z-index:2;font-size:19px;line-height:1.55;max-width:62%;margin:12px 0 5px;letter-spacing:-.3px}
.promo-tile p{position:relative;z-index:2;font-size:11px;line-height:1.8;max-width:58%;font-weight:600}
.promo-tile img{z-index:1;left:0;bottom:0;width:49%;height:96%;object-fit:contain;mix-blend-mode:multiply;filter:drop-shadow(0 10px 12px rgba(40,54,32,.12));transition:transform .4s}
.promo-tile:hover img{transform:scale(1.09) translateY(-4px)}
.promo-arrow{z-index:3;right:18px;bottom:16px;width:32px;height:32px;border:1px solid rgba(255,255,255,.25);box-shadow:0 5px 12px rgba(0,0,0,.12);transition:transform .25s}
.promo-tile:hover .promo-arrow{transform:translateX(-4px)}
.promo-pink .promo-arrow,.promo-yellow .promo-arrow{background:#234d38;color:#fff}

.fresh-bottom-banner{min-height:300px;margin:64px 0 18px;padding:38px 48px;border:1px solid #d9edf0;border-radius:28px;background:radial-gradient(circle at 83% 50%,rgba(255,255,255,.8),transparent 32%),linear-gradient(110deg,#d8f0f5 0%,#e8f8f2 58%,#d6eee9 100%);box-shadow:0 16px 40px rgba(43,105,104,.09);isolation:isolate}
.fresh-bottom-banner:before{content:"";position:absolute;right:35%;top:-100px;width:300px;height:300px;border:1px solid rgba(34,120,84,.12);border-radius:50%;box-shadow:0 0 0 25px rgba(255,255,255,.13),0 0 0 52px rgba(255,255,255,.1);z-index:-1}
.bottom-banner-copy{max-width:48%}
.bottom-banner-copy>span{display:inline-block;padding:6px 13px;border-radius:30px;background:rgba(255,255,255,.72);color:#23734d;border:1px solid #cfe7dc}
.bottom-banner-copy h2{font-size:clamp(25px,2.7vw,35px);line-height:1.5;color:#173e2d;margin:10px 0}
.bottom-banner-copy p{font-size:12px;line-height:2;color:#526e60;max-width:390px}
.bottom-banner-copy a{padding:12px 19px;border-radius:13px;background:linear-gradient(135deg,#238b55,#12623e);box-shadow:0 9px 20px rgba(23,107,69,.2);transition:transform .25s}
.bottom-banner-copy a:hover{transform:translateY(-3px);color:#fff}
.fresh-bottom-banner>img{width:57%;height:115%;left:0;bottom:-10px;object-fit:contain;filter:drop-shadow(0 16px 16px rgba(45,85,48,.13));mix-blend-mode:multiply}

@media(max-width:900px){
 .fresh-hero{min-height:320px;padding:28px 30px;grid-template-columns:1fr 1fr}
 .fresh-hero-art{height:245px}.promo-tile{min-height:175px}.promo-tile h3{font-size:17px}
}
@media(max-width:620px){
 .fresh-hero{grid-template-columns:1fr;gap:0;padding:20px 20px 24px;margin-top:17px;border-radius:22px}
 .fresh-hero-art{grid-row:1;height:190px;margin:-4px -5px 4px}.fresh-hero-copy{grid-row:2}
 .fresh-hero h1{font-size:29px;margin:10px 0}.fresh-hero p{font-size:12px;line-height:1.95}
 .fresh-hero:after{font-size:22px;left:14px;bottom:12px}.fresh-hero-note{font-size:9px;flex-wrap:wrap}
 .promo-trio{grid-template-columns:1fr;gap:12px;margin:17px 0 38px}
 .promo-tile{min-height:154px;padding:17px 18px;border-radius:19px}.promo-tile h3{font-size:17px;max-width:62%;margin:8px 0 3px}.promo-tile p{font-size:10px;max-width:58%}.promo-tile img{width:43%;height:100%}
 .fresh-bottom-banner{min-height:320px;margin:42px 0 10px;padding:22px 20px;border-radius:22px;align-items:flex-start}
 .bottom-banner-copy{max-width:100%}.bottom-banner-copy h2{font-size:25px}.bottom-banner-copy p{max-width:68%;font-size:10px}
 .fresh-bottom-banner>img{width:88%;height:62%;left:-8px;bottom:-5px;opacity:.96}
}
@media(prefers-reduced-motion:reduce){.fresh-hero-art img,.promo-tile,.promo-tile img,.promo-arrow,.fresh-hero-btn,.bottom-banner-copy a{transition:none}}


/* ===== بنرهای اختصاصی سوپرمارکت: حبوبات، قند و چای، لبنیات و پروتئین ===== */
.fresh-hero{background:linear-gradient(110deg,#e7f4e9 0%,#f8f5e9 52%,#e4f2ed 100%);border:1px solid #dcebdd}
.fresh-hero h1 strong{color:#b56b24}
.fresh-kicker{background:#fff8e9;color:#95601f;border-color:#f2dfbd}
.fresh-hero-art img{filter:drop-shadow(0 18px 17px rgba(60,75,42,.14))}
.promo-trio{grid-template-columns:repeat(3,minmax(0,1fr))}
.promo-tile{min-height:205px;padding:22px 23px}
.promo-green{background:linear-gradient(125deg,#155b40,#27875d 62%,#a7d6a0)}
.promo-pink{background:linear-gradient(125deg,#fff0df,#f5d4bd 58%,#eab3a0);color:#583b2b}
.promo-yellow{background:linear-gradient(125deg,#fff4c9,#f6df8c 58%,#eec15b);color:#4c3a13}
.promo-tile h3{font-size:20px;max-width:64%}
.promo-tile p{font-size:11px;max-width:62%}
.promo-tile img{width:48%;height:94%;object-fit:contain;mix-blend-mode:multiply}
.promo-label{font-size:10px;font-weight:900}
.fresh-bottom-banner{background:linear-gradient(110deg,#f3ead6 0%,#f8f2e6 55%,#e6f1e3 100%);border-color:#e8dfca}
.bottom-banner-copy>span{color:#8a5b25}
.bottom-banner-copy h2{color:#264b36}
@media(max-width:620px){.promo-trio{grid-template-columns:1fr}.promo-tile{min-height:165px}.promo-tile img{width:43%;height:100%}}


/* چهار بنر تصویری اختصاصی صفحه اصلی */
.grocery-banner-area{width:100%;margin:26px 0 42px;}
.grocery-main-banner{display:block;width:100%;overflow:hidden;border-radius:24px;line-height:0;background:#edf5e8;box-shadow:0 12px 30px rgba(28,75,42,.10);}
.grocery-main-banner img{display:block;width:100%;height:auto;aspect-ratio:8/3;object-fit:cover;}
/* سه تصویر دسته‌بندی با عرض کاملاً مساوی */
.grocery-category-banners{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px;margin-top:18px;}
.grocery-category-banner{display:block;min-width:0;overflow:hidden;border-radius:19px;line-height:0;background:#f4f4ed;box-shadow:0 8px 22px rgba(28,75,42,.08);transition:transform .22s ease,box-shadow .22s ease;}
.grocery-category-banner:hover{transform:translateY(-4px);box-shadow:0 14px 28px rgba(28,75,42,.14);}
.grocery-category-banner img{display:block;width:100%;height:auto;aspect-ratio:4/3;object-fit:cover;}
@media(max-width:700px){
 .grocery-banner-area{margin:17px 0 32px}
 .grocery-main-banner{border-radius:17px}
 .grocery-main-banner img{aspect-ratio:2.25/1}
 .grocery-category-banners{grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;margin-top:12px}
 .grocery-category-banner{border-radius:11px}
 .grocery-category-banner img{aspect-ratio:1/1.15}
}
@media(max-width:420px){
 .grocery-category-banners{gap:5px}
 .grocery-category-banner{border-radius:8px}
 .grocery-category-banner img{aspect-ratio:1/1.25}
 .grocery-main-banner img{aspect-ratio:1.9/1}
}

/* بنر پایینی: نمایش کل تصویر به‌صورت یکپارچه و بدون برش */
.fresh-bottom-banner{
    display:block !important;
    position:relative;
    width:100%;
    min-height:0 !important;
    height:auto !important;
    aspect-ratio:984 / 319;
    margin:55px 0 12px;
    padding:0 !important;
    overflow:hidden;
    border:0;
    border-radius:22px;
    background:transparent !important;
    box-shadow:0 10px 28px rgba(35,75,48,.10);
}
.bottom-banner-full-link{
    display:block;
    width:100%;
    height:100%;
    line-height:0;
}
.fresh-bottom-banner .bottom-banner-full-link img{
    position:static !important;
    display:block;
    width:100% !important;
    height:100% !important;
    aspect-ratio:984 / 319;
    object-fit:contain !important;
    object-position:center;
    opacity:1 !important;
    mix-blend-mode:normal !important;
    filter:none !important;
}
@media(max-width:620px){
    .fresh-bottom-banner{
        margin:35px 0 12px;
        border-radius:14px;
        aspect-ratio:984 / 319;
    }
}

</style>
</head>
<body>

<?php require __DIR__ . '/includes/site_header.php'; ?>

<div class="fresh-benefits">
  <div class="fresh-benefits-inner">
    <div class="benefit-item"><span class="benefit-icon">🚚</span><span><b>ارسال سریع</b><small>تحویل در کوتاه‌ترین زمان</small></span></div>
    <div class="benefit-item"><span class="benefit-icon">🥬</span><span><b>تازگی و کیفیت</b><small>انتخاب روزانه محصولات</small></span></div>
    <div class="benefit-item"><span class="benefit-icon">💳</span><span><b>پرداخت امن</b><small>خرید مطمئن و آسان</small></span></div>
    <div class="benefit-item"><span class="benefit-icon">🎁</span><span><b>تخفیف‌های جذاب</b><small>صرفه‌جویی در خرید خانه</small></span></div>
  </div>
</div>

<div class="container">

<!-- ============ Hero ============ -->
<?php
$__hd = ['badge' => 'جشنواره فروش ویژه', 't1' => 'تازه و خوشمزه،', 't2' => 'همیشه در خانه شما',
    'sub' => 'خرید آسان و سریع انواع مواد غذایی تازه، میوه و سبزیجات، لبنیات و کالاهای روزمره با بهترین قیمت.',
    'b1' => 'مشاهده و خرید', 'b1u' => 'archive.php', 'b2' => 'لیست قیمت روز', 'b2u' => 'archive.php?sort=cheap',
    'c1tag' => 'تازه و روزانه', 'c1t' => 'میوه و سبزی تازه', 'c1s' => 'طراوت و کیفیت در هر خرید', 'c1l' => 'خرید میوه', 'c1u' => 'archive.php?sort=best',
    'c2tag' => 'تخفیف‌های جذاب', 'c2t' => 'سبد خرید اقتصادی', 'c2s' => 'کالاهای ضروری با قیمت مناسب', 'c2l' => 'مشاهده تخفیف‌ها', 'c2u' => 'archive.php?sort=discount'];
$__hs = json_decode(site_get($pdo, 'home_hero', ''), true);
if (is_array($__hs)) foreach ($__hs as $__k => $__v) if (isset($__hd[$__k]) && trim((string)$__v) !== '') $__hd[$__k] = (string)$__v;
$__u = function ($u) { return preg_match('#^(https?://|[A-Za-z0-9_./?=&%-]+$)#', $u) ? htmlspecialchars($u) : 'archive.php'; };
$__e = function ($k) use ($__hd) { return htmlspecialchars($__hd[$k]); };
?>
<!-- یک بنر بزرگ + سه بنر هم‌اندازه از پوشه assets/grocery-banners -->
<section class="grocery-banner-area" aria-label="دسته‌بندی‌های فروشگاه مواد غذایی">
  <a class="grocery-main-banner" href="archive.php" aria-label="ورود به فروشگاه مواد غذایی">
    <img src="assets/grocery-banners/01-hero-basket.jpg" alt="سبد پر از مواد غذایی؛ مواد کالا برگی" fetchpriority="high">
  </a>
  <div class="grocery-category-banners">
    <a class="grocery-category-banner" href="archive.php?sort=best">
      <img src="assets/grocery-banners/02-dairy-eggs.jpg" alt="لبنیات و تخم مرغ تازه" loading="lazy">
    </a>
    <a class="grocery-category-banner" href="archive.php?sort=best">
      <img src="assets/grocery-banners/03-legumes-rice.jpg" alt="حبوبات و برنج" loading="lazy">
    </a>
    <a class="grocery-category-banner" href="archive.php">
      <img src="assets/grocery-banners/04-chicken-fish.jpg" alt="مرغ و ماهی تازه" loading="lazy">
    </a>
  </div>
</section>

<!-- ============ پیشنهاد ویژه ============ -->
<?php if (!empty($featuredProducts)): ?>
<section class="section">
    <div class="section-header">
        <h2>پرفروش‌ترین‌های هفته</h2>
        <div class="divider"><span>◆</span></div>
    </div>
    <div class="products-grid">
        <?php foreach ($featuredProducts as $p) ms_product_card($p); ?>
    </div>
    <div class="section-more"><a href="archive.php">مشاهده همه محصولات</a></div>
</section>
<?php endif; ?>

<!-- ============ تخفیف‌ها ============ -->
<?php if (!empty($discountProducts)): ?>
<section class="section">
    <div class="section-header">
        <h2>محبوب‌ترین محصولات</h2>
        <div class="divider"><span>◆</span></div>
    </div>
    <div class="products-grid">
        <?php foreach ($discountProducts as $p) ms_product_card($p, true); ?>
    </div>
    <div class="section-more"><a href="archive.php">مشاهده همه تخفیف‌ها</a></div>
</section>
<?php endif; ?>

<!-- ============ جدیدترین‌ها ============ -->
<?php if (!empty($newestProducts)): ?>
<section class="section">
    <div class="section-header">
        <h2>تازه رسیده‌ها</h2>
        <div class="divider"><span>◆</span></div>
    </div>
    <div class="products-grid">
        <?php foreach ($newestProducts as $p) ms_product_card($p); ?>
    </div>
    <div class="section-more"><a href="archive.php">مشاهده همه محصولات</a></div>
</section>
<?php endif; ?>

<section class="fresh-bottom-banner" aria-label="بنر تبلیغاتی مواد غذایی">
  <a class="bottom-banner-full-link" href="archive.php" aria-label="مشاهده محصولات فروشگاه">
    <img src="<?= htmlspecialchars($bottomBannerImage) ?>" alt="از حبوبات و چای تا لبنیات و گوشت تازه" loading="lazy">
  </a>
</section>
</div>

<?php require __DIR__ . '/includes/site_footer.php'; ?>

<script>
function addToCart(productId, event) {
    if (event) event.preventDefault();
    fetch('add_to_cart.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id=' + productId
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            if (data.cart_count > 0) {
                const faCount = String(data.cart_count).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
                const badge = document.querySelector('.cart-badge');
                if (badge) {
                    badge.textContent = faCount;
                } else {
                    const cartLink = document.querySelector('.header-actions a[href="cart.php"]');
                    if (cartLink) {
                        const span = document.createElement('span');
                        span.className = 'cart-badge';
                        span.textContent = faCount;
                        cartLink.appendChild(span);
                    }
                }
            }
            showToast('✅ ' + data.message, false);
        } else {
            showToast('❌ ' + data.message, true);
        }
    })
    .catch(() => showToast('خطا در ارتباط با سرور', true));
}

function showToast(message, isError) {
    if (isError === undefined) isError = false;
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'toast ' + (isError ? 'error' : 'success');
    toast.textContent = message;
    document.body.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add('show'));

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 400);
    }, 2500);
}
</script>

</body>
</html>