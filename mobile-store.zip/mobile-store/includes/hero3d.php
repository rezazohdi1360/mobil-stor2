<?php
/**
 * includes/hero3d.php
 * گوشی سه‌بعدی برای Hero صفحه اصلی (فقط index.php)
 * بدون هیچ وابستگی به دیتابیس؛ اگر WebGL پشتیبانی نشود، همان ایموجی قبلی نمایش داده می‌شود.
 */
?>
<div class="h3d" id="h3d" aria-hidden="true"><canvas id="h3d-canvas"></canvas></div>

<style>
/* جای خالی سمت چپ برای گوشی (سایت RTL است، متن سمت راست می‌ماند) */
.hero-main.hero-3d{padding-left:40%}
.h3d{position:absolute!important;left:0;top:0;bottom:0;width:40%;pointer-events:none}
.h3d canvas{display:block;width:100%;height:100%;opacity:0;transition:opacity .6s}
.hero-3d-on .h3d canvas{opacity:1}
.hero-3d-on .hero-wm{display:none}
@media(max-width:900px){
  .hero-main.hero-3d{padding-left:24px}
  .h3d{position:relative!important;width:100%;height:250px;order:-1;margin-bottom:8px}
}
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js" defer></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
  var wrap = document.getElementById('h3d'), canvas = document.getElementById('h3d-canvas');
  if (!wrap || !window.THREE) return;
  var T = THREE, hero = wrap.parentNode, renderer;
  try {
    renderer = new T.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true, powerPreference: 'low-power' });
  } catch (e) { return; }

  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.outputEncoding = T.sRGBEncoding;

  var scene = new T.Scene();
  var camera = new T.PerspectiveCamera(32, 1, 0.1, 50);

  /* ---------- نور ---------- */
  scene.add(new T.AmbientLight(0xffffff, 0.6));
  var key = new T.DirectionalLight(0xffffff, 1.0); key.position.set(3, 4, 6); scene.add(key);
  var gold = new T.PointLight(0xd9b968, 1.5, 20); gold.position.set(-4, -2, 4); scene.add(gold);
  var rim = new T.PointLight(0x4a78c2, 1.2, 20); rim.position.set(4, 2, -3); scene.add(rim);

  /* ---------- بدنه گوشی ---------- */
  function roundedRect(w, h, r) {
    var s = new T.Shape(), x = -w / 2, y = -h / 2, PI = Math.PI;
    s.moveTo(x + r, y);
    s.lineTo(x + w - r, y);     s.absarc(x + w - r, y + r, r, -PI / 2, 0, false);
    s.lineTo(x + w, y + h - r); s.absarc(x + w - r, y + h - r, r, 0, PI / 2, false);
    s.lineTo(x + r, y + h);     s.absarc(x + r, y + h - r, r, PI / 2, PI, false);
    s.lineTo(x, y + r);         s.absarc(x + r, y + r, r, PI, PI * 1.5, false);
    return s;
  }
  var bodyGeo = new T.ExtrudeGeometry(roundedRect(1.7, 3.5, 0.32), {
    depth: 0.14, bevelEnabled: true, bevelThickness: 0.05, bevelSize: 0.05, bevelSegments: 4, curveSegments: 24
  });
  bodyGeo.translate(0, 0, -0.07);
  var phone = new T.Group();
  phone.add(new T.Mesh(bodyGeo, new T.MeshStandardMaterial({ color: 0xb8923a, metalness: 0.85, roughness: 0.32 })));

  /* ---------- صفحه نمایش (با Canvas کشیده می‌شود) ---------- */
  var sc = document.createElement('canvas'); sc.width = 512; sc.height = 1075;
  function drawScreen() {
    var g = sc.getContext('2d'), W = sc.width, H = sc.height;
    function rr(x, y, w, h, r) {
      g.beginPath(); g.moveTo(x + r, y);
      g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
      g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
    }
    g.clearRect(0, 0, W, H);
    rr(0, 0, W, H, 56); g.fillStyle = '#05080d'; g.fill();
    rr(14, 14, W - 28, H - 28, 44);
    var bg = g.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#2a3d5c'); bg.addColorStop(1, '#111c2d');
    g.fillStyle = bg; g.fill();
    g.save(); g.clip();

    rr(W / 2 - 70, 28, 140, 34, 17); g.fillStyle = '#05080d'; g.fill();

    g.direction = 'rtl'; g.textAlign = 'right';
    g.fillStyle = '#fff'; g.font = '700 38px Vazirmatn,Tahoma,sans-serif';
    g.fillText('فروشگاه موبایل', W - 44, 130);
    rr(36, 160, W - 72, 64, 32); g.fillStyle = 'rgba(255,255,255,.1)'; g.fill();

    var bn = g.createLinearGradient(36, 256, W - 36, 506);
    bn.addColorStop(0, '#d9b968'); bn.addColorStop(1, '#b8923a');
    rr(36, 256, W - 72, 250, 32); g.fillStyle = bn; g.fill();
    g.fillStyle = '#fff'; g.font = '800 44px Vazirmatn,Tahoma,sans-serif';
    g.fillText('جشنواره تخفیف', W - 72, 350);
    g.font = '600 28px Vazirmatn,Tahoma,sans-serif';
    g.fillText('تا ۴۰٪ تخفیف ویژه', W - 72, 404);
    rr(W - 72 - 170, 436, 170, 46, 23); g.fillStyle = '#1b2a41'; g.fill();
    g.fillStyle = '#d9b968'; g.textAlign = 'center'; g.font = '700 24px Vazirmatn,Tahoma,sans-serif';
    g.fillText('خرید', W - 72 - 85, 469);

    var tw = (W - 72 - 24) / 2, rows = [540, 764];
    rows.forEach(function (ty) {
      [36, 36 + tw + 24].forEach(function (tx) {
        rr(tx, ty, tw, 200, 26); g.fillStyle = 'rgba(255,255,255,.08)'; g.fill();
        var pg = g.createLinearGradient(0, ty + 20, 0, ty + 130);
        pg.addColorStop(0, '#d9b968'); pg.addColorStop(1, '#7a5a1c');
        rr(tx + tw / 2 - 30, ty + 20, 60, 104, 12); g.fillStyle = pg; g.fill();
        rr(tx + 22, ty + 146, tw - 44, 14, 7); g.fillStyle = 'rgba(217,185,104,.9)'; g.fill();
        rr(tx + 22, ty + 170, (tw - 44) * 0.55, 10, 5); g.fillStyle = 'rgba(255,255,255,.25)'; g.fill();
      });
    });

    rr(36, 990, W - 72, 56, 28); g.fillStyle = 'rgba(255,255,255,.08)'; g.fill();
    for (var i = 0; i < 4; i++) {
      g.beginPath(); g.arc(W / 2 + (i - 1.5) * 90, 1018, i === 1 ? 10 : 7, 0, Math.PI * 2);
      g.fillStyle = i === 1 ? '#d9b968' : 'rgba(255,255,255,.35)'; g.fill();
    }
    g.restore();
  }
  drawScreen();
  var tex = new T.CanvasTexture(sc);
  tex.encoding = T.sRGBEncoding;
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
  var screen = new T.Mesh(new T.PlaneGeometry(1.62, 1.62 * sc.height / sc.width),
    new T.MeshBasicMaterial({ map: tex, transparent: true }));
  screen.position.z = 0.125;
  phone.add(screen);
  scene.add(phone);

  /* ---------- حلقه‌ها و ذرات طلایی ---------- */
  var rings = new T.Group();
  [[2.05, 1.2, 0, 0], [2.4, 0.4, 0, 1.0]].forEach(function (c) {
    var m = new T.Mesh(new T.TorusGeometry(c[0], 0.012, 8, 140),
      new T.MeshBasicMaterial({ color: 0xd9b968, transparent: true, opacity: 0.55 }));
    m.rotation.set(c[1], c[2], c[3]); rings.add(m);
  });
  scene.add(rings);

  var N = 70, pos = new Float32Array(N * 3);
  for (var i = 0; i < N; i++) {
    var r = 1.9 + Math.random() * 1.3, a = Math.random() * Math.PI * 2, b = Math.acos(2 * Math.random() - 1);
    pos[i * 3] = r * Math.sin(b) * Math.cos(a); pos[i * 3 + 1] = r * Math.sin(b) * Math.sin(a); pos[i * 3 + 2] = r * Math.cos(b);
  }
  var pg = new T.BufferGeometry(); pg.setAttribute('position', new T.BufferAttribute(pos, 3));
  var dots = new T.Points(pg, new T.PointsMaterial({ color: 0xd9b968, size: 0.05, transparent: true, opacity: 0.8 }));
  scene.add(dots);

  /* ---------- اندازه ---------- */
  function resize() {
    var w = wrap.clientWidth, h = wrap.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    var need = Math.max(5.4, 4.6 / camera.aspect);
    camera.position.set(0, 0, need / (2 * Math.tan(camera.fov * Math.PI / 360)));
    camera.updateProjectionMatrix();
    if (reduce) update(0);
  }

  /* ---------- حرکت ---------- */
  var cur = { x: 0, y: 0 }, tgt = { x: 0, y: 0 };
  hero.addEventListener('pointermove', function (e) {
    var r = hero.getBoundingClientRect();
    tgt.x = Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width - 0.5) * 2));
    tgt.y = Math.max(-1, Math.min(1, ((e.clientY - r.top) / r.height - 0.5) * 2));
  });
  hero.addEventListener('pointerleave', function () { tgt.x = 0; tgt.y = 0; });

  function update(t) {
    cur.x += (tgt.x - cur.x) * 0.06; cur.y += (tgt.y - cur.y) * 0.06;
    phone.rotation.y = 0.25 + Math.sin(t * 0.7) * 0.6 + cur.x * 0.45;
    phone.rotation.x = -0.05 + Math.sin(t * 0.9) * 0.05 + cur.y * 0.3;
    phone.position.y = Math.sin(t * 1.2) * 0.1;
    rings.rotation.y = t * 0.25; rings.rotation.z = t * 0.12;
    dots.rotation.y = -t * 0.08;
    renderer.render(scene, camera);
  }

  var clock = new T.Clock(), visible = true, raf = 0;
  function frame() {
    raf = 0;
    if (!visible || document.hidden) return;
    update(clock.getElapsedTime());
    raf = requestAnimationFrame(frame);
  }
  function start() { if (!raf && !reduce) raf = requestAnimationFrame(frame); }

  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (en) { visible = en[0].isIntersecting; if (visible) start(); }).observe(wrap);
  }
  document.addEventListener('visibilitychange', start);
  if ('ResizeObserver' in window) new ResizeObserver(resize).observe(wrap);
  else window.addEventListener('resize', resize);

  resize();
  hero.classList.add('hero-3d-on');
  update(0);
  start();

  /* وقتی فونت وزیرمتن لود شد، صفحه گوشی دوباره کشیده شود */
  if (document.fonts && document.fonts.load) {
    document.fonts.load('700 38px Vazirmatn').then(function () {
      drawScreen(); tex.needsUpdate = true; if (reduce) update(0);
    });
  }
});
</script>
